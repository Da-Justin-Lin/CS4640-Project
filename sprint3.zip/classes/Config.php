<?php

class Config {
    public static $db = [
        "host" => "localhost",
        "user" => "dl2de",
        "pass" => "AlzMbDJrxqwN",
        "database" => "dl2de"
    ];
}